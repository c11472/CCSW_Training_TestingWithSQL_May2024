package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AccessFrameDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd;
		wd = new ChromeDriver();
	  //  WebElement Text1=wd.findElement(By.xpath("//*[@id=\"content\"]/p[1]"));
		
		wd.get("https://jqueryui.com/draggable/");

		
		Thread.sleep(2000);
		wd.switchTo().frame(0);
		
	String output=	wd.findElement(By.xpath("//p[contains(text(),'Drag me around')]")).getText();
	System.out.println(output);
	
	wd.switchTo().parentFrame();
    WebElement Text1=wd.findElement(By.xpath("//*[@id=\"content\"]/p[1]"));

	
	String Textval = Text1.getText();
	
	System.out.println(Textval);
		
		

	}

}
