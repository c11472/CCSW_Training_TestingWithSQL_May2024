package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tagNameDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver wd= new ChromeDriver();
		// To count the element belongs to tagName input
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
		
		
		String TagName1 = wd.findElement(By.xpath("(//a[contains(text(),'Forgotten Password')])[2]")).getTagName();
		System.out.println(TagName1);
		
		// getText
		String resVal = wd.findElement(By.xpath("(//a[contains(text(),'Forgotten Password')])[2]")).getText();
		
		System.out.println(resVal);
		//wd.findElement(null)
		//wd.findElements(null)
		
		
		List <WebElement> al =  wd.findElements(By.tagName("a"));
		
		int count = al.size();
		
		System.out.println(count);
		
		// Fetch the data or name 
		//List traversal
		
	     for(int i=0;i<=count-1;i++) {
	    	 String name = al.get(i).getText();
	    	 System.out.println(name);
	     }
	     
	     //check Delivery Information
	     
	     String exp1 ="Chekin";
	     
	     for(int i=0;i<=count-1;i++) {
	    	 String name = al.get(i).getText();
	    	 if(name.equals(exp1)) {
	    		 System.out.println("The link is valid "+ "  " + name);
	    		 break;
	    	 }
	    	 else {
	    		 System.out.println("invalid link");
	    		 break;
	    	 }
	    	
	     }
	    
	     
	     
	     
	     

	     
	     
		

	}

}
