package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandelingDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd;
		String ExpAlertMessage = "Please enter a valid user name";
		
		wd = new ChromeDriver();
		
	
		
		
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
		WebElement username = wd.findElement(By.name("login"));
		WebElement button = wd.findElement(By.xpath("//input[@type='submit']"));
		
		button.click();
		
		Alert al = wd.switchTo().alert();
		// Extract the alert message using getText
		String AlertMessage = al.getText();
		
		System.out.println("The alert message is : " + " " + AlertMessage);
		// Validate the alert message
		if(AlertMessage.equals(ExpAlertMessage)) {
			System.out.println("The alert message is correct");
		}
		else {
			System.out.println("The alert message  is incorrect");
		}
		Thread.sleep(2000);
		
		// Handle the alert
		
		al.accept();
		
		
		// Enter the user name
		Thread.sleep(2000);

		username.sendKeys("gayatri@rediff.com");
		
		

	}

}
