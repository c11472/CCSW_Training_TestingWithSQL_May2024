package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AccessLib1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		Library1 obj = new Library1();
		WebDriver wd = new ChromeDriver();
		// init lib
		obj.init_Library1(wd);
		
		
		// method call from lib
		
		obj.Google_Search_Invoke();
		
		

	}

}
