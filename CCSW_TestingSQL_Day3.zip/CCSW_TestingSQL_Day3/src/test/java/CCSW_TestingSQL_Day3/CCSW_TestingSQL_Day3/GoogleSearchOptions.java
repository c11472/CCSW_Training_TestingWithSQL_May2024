package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class GoogleSearchOptions {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		wd.get("https://www.google.com");
		
		wd.findElement(By.name("q")).sendKeys("selenium testing");
		
	
		
 	   String s1 ="/html/body/div[1]/div[3]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li[";
String s2 = "]";

Thread.sleep(5000);
String mxp ;
       for(int i=1;i<=10;i++) {
    	   Thread.sleep(1000);
    	  WebElement el = wd.findElement(By.xpath(s1+i+s2));
    	 String Options= el.getText();
    	 
    	 System.out.println(Options);
    	 
        
    	   
       }
		
		

	}

}
