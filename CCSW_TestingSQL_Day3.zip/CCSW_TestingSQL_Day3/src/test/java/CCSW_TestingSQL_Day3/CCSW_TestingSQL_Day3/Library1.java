package CCSW_TestingSQL_Day3.CCSW_TestingSQL_Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Library1 {
	static WebDriver wd;
	
	public void init_Library1(WebDriver wd) {
		
		this.wd = wd;
		
	}

	public  void Google_Search_Invoke() {
		
		wd.get("https://www.google.com");
		wd.findElement(By.name("q")).sendKeys("test automation");
	
       
	}

}

